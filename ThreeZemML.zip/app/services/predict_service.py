from app.models.model_loader import get_model
from app.schemas.request import PredictRequest
from app.utils.preprocessor import preprocess
from app.utils.postprocessor import postprocess

def predict_service(request: PredictRequest):
    # lgbm 모델 파일명을 전달
    model = get_model("lgbm_model.pkl")
    
    # request에서 usage_data를 전처리기에게 전달
    x = preprocess(request.usage_data)
    
    # 전처리된 데이터로 예측 수행
    pred = model.predict(x)
    
    # 예측 결과를 후처리
    result = postprocess(pred)
    
    return result