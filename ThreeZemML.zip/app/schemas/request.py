from pydantic import BaseModel
from typing import List

class PredictRequest(BaseModel):
    usage_data: List[float]

