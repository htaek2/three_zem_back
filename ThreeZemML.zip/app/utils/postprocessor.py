import numpy as np

def postprocess(prediction: np.ndarray) -> list[float]:
    """
    모델 예측 결과(numpy array)를 JSON으로 변환 가능한 리스트로 변환.
    """
    return prediction.tolist()