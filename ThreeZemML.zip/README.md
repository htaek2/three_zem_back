# How to run

1. pip install -r requirements.txt
1. uvicorn app.main:app --reload

